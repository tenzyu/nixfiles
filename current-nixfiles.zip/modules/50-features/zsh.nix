{
  flake.modules.nixos.zsh = {
    config,
    pkgs,
    lib,
    ...
  }: {
    config = lib.mkIf config.local.features.zsh.enable {
      programs.zsh.enable = lib.mkDefault true;
      environment.pathsToLink = lib.mkDefault ["/share/zsh"];
      environment.shells = lib.mkDefault [pkgs.zsh];
      environment.enableAllTerminfo = lib.mkDefault true;
    };
  };

  flake.modules.homeManager.zsh = {
    config,
    lib,
    ...
  }: {
    config = lib.mkIf config.local.features.zsh.enable {
      home.file."${config.xdg.configHome}/zsh/zshrc.d".source = ../../assets/zshrc;

      programs.zsh = {
        enable = true;

        dotDir = "${config.xdg.configHome}/zsh";

        autosuggestion.enable = true;
        syntaxHighlighting.enable = true;

        history = {
          path = "${config.xdg.stateHome}/zsh/history";
          save = 1000000;
          size = 1000000;
        };

        shellAliases = {
          c = "clear";
          q = "exit";
          shutdown = "systemctl poweroff";
          update-grub = "sudo grub-mkconfig -o /boot/grub/grub.cfg";

          v = "${config.home.sessionVariables.EDITOR}";
          vi = "${config.home.sessionVariables.EDITOR}";
          vim = "${config.home.sessionVariables.EDITOR}";
          n = "${config.home.sessionVariables.EDITOR}";

          nf = "fastfetch";
          ls = "eza --color=always --long --git --no-filesize --icons=always --no-time --no-user --no-permissions";
          ll = "eza -al --icons=always";
          lt = "eza -a --tree --level=3 --icons=always";
          lg = "lazygit";
          ta = "tmux attach -t main";
          tn = "tmux new -As main";
          tls = "tmux ls";
          wifi = "nmtui";
          zed = "zeditor";
          wget = "wget --hsts-file='${config.xdg.dataHome}/wget-hsts'";
          grep = "rg";
          cd = "z";
          moe = "moree";
          fk = "thefuck";
          tk = "thefuck";
          yy = "yazi";
        };

        initContent = ''
          for f in ${config.xdg.configHome}/zsh/zshrc.d/*; do
              if [ ! -d $f ] ;then
                  source $f
              fi
          done

          if [[ $(tty) == *"pts"* ]]; then
              fastfetch --config examples/13
          else
              echo
              if [ -f /bin/hyprctl ]; then
                  echo "Start Hyprland with command Hyprland"
              fi
          fi
        '';
      };
    };
  };
}

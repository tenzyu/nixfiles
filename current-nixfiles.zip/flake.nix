{
  description = "tenzyu's nixfiles";

  outputs = inputs:
    inputs.flake-parts.lib.mkFlake {inherit inputs;}
    (inputs.import-tree ./modules);

  inputs = {
    # -- nixpkgs
    nixpkgs.url = "github:nixos/nixpkgs/nixos-26.05";
    nixpkgs-unstable.url = "github:nixos/nixpkgs/nixpkgs-unstable";

    # -- Theme
    # NOTE: omit follows, for cache hit.
    # catppuccin using "https://channels.nixos.org/nixpkgs-unstable/nixexprs.tar.xz" btw
    catppuccin.url = "github:catppuccin/nix/release-26.05";

    # -- Nix ecosystems
    home-manager = {
      url = "github:nix-community/home-manager/release-26.05";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    systems.url = "github:nix-systems/default";
    flake-utils = {
      url = "github:numtide/flake-utils";
      inputs.systems.follows = "systems";
    };
    flake-compat = {
      url = "github:NixOS/flake-compat";
      flake = false;
    };

    # -- Dendritic Pattern
    import-tree.url = "github:vic/import-tree";
    flake-parts = {
      url = "github:hercules-ci/flake-parts";
      inputs.nixpkgs-lib.follows = "nixpkgs";
    };

    # -- Development
    llm-agents = {
      url = "github:numtide/llm-agents.nix";
      inputs.nixpkgs.follows = "nixpkgs-unstable";
      inputs.systems.follows = "systems";
      inputs.flake-parts.follows = "flake-parts";
    };
    lazyvim = {
      url = "github:pfassina/lazyvim-nix";
      inputs.nixpkgs.follows = "nixpkgs";
      inputs.flake-utils.follows = "flake-utils";
    };

    castalia = {
      url = "github:tenzyu/tenzyudotcom/develop?dir=product/apps/castalia";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    onair = {
      url = "github:hiraginoyuki/onair";
      inputs.nixpkgs.follows = "nixpkgs-unstable";
    };

    # -- Other Ecosystems
    nixos-wsl = {
      url = "github:nix-community/NixOS-WSL";
      inputs.nixpkgs.follows = "nixpkgs";
      inputs.flake-compat.follows = "flake-compat";
    };
    nixgl = {
      url = "github:nix-community/nixGL";
      inputs.nixpkgs.follows = "nixpkgs";
      inputs.flake-utils.follows = "flake-utils";
    };
  };
}

---
name: nix-function-catalog
description: Use when editing Nix code that manipulates attrsets, function arguments, module imports, flakes, or NixOS/Home Manager modules. Focuses on mistake-prone Nix builtins, nixpkgs lib helpers, and module argument boundaries.
---

## Purpose

This skill is a mistake-driven Nix function catalog.

Use it before changing Nix code that contains:

- `builtins.functionArgs`
- `builtins.intersectAttrs`
- `builtins.hasAttr`
- `builtins.attrNames`
- `builtins.foldl'`
- `builtins.seq`
- `builtins.getFlake`
- `//`
- `lib.mkMerge`
- `lib.mapAttrs`
- `lib.filterAttrs`
- `lib.attrValues`
- `lib.unique`
- `lib.naturalSort`
- NixOS module functions using `{ pkgs, lib, modulesPath, config, ... }`

Do not invent a new architecture. Do not encode project-specific concepts. Use the catalog to avoid known Nix mistakes.

## First rule: know which function layer you are editing

A file imported by flake-parts is not automatically a NixOS module.

Wrong:

```nix
{ pkgs, modulesPath, ... }: {
  flake.modules.nixos.example = {
    imports = [ (modulesPath + "/profiles/qemu-guest.nix") ];
    environment.systemPackages = [ pkgs.hello ];
  };
}
```

Correct:

```nix
{ ... }: {
  flake.modules.nixos.example = { pkgs, modulesPath, ... }: {
    imports = [ (modulesPath + "/profiles/qemu-guest.nix") ];
    environment.systemPackages = [ pkgs.hello ];
  };
}
```

`pkgs`, `modulesPath`, `config`, and NixOS options belong inside the NixOS module function.

Outer flake modules usually receive flake-level arguments. Inner NixOS modules receive NixOS module arguments.

## `builtins.functionArgs`

Use this to inspect the formal attrset arguments declared by a function.

```nix
builtins.functionArgs ({ lib, user, ... }: {})
# => { lib = false; user = false; }
```

Important trap:

```nix
builtins.functionArgs (args: args)
# => {}
```

A positional function like `args: ...` does not declare named attrset parameters. If you use `functionArgs` to filter a context, a positional function receives `{}`.

Prefer explicit attrset parameters when the function expects context:

```nix
{ lib, user, ... }: ...
```

Avoid this when the function expects named context:

```nix
args: ...
```

## `builtins.intersectAttrs`

Use this to pass only supported named arguments into a function.

Correct pattern:

```nix
callWithKnownArgs = args: fn:
  fn (builtins.intersectAttrs (builtins.functionArgs fn) args);
```

`builtins.intersectAttrs a b` keeps keys that exist in both sets and takes values from the second set.

Example:

```nix
builtins.intersectAttrs
  { lib = false; user = false; }
  { lib = "LIB"; user = "USER"; pkgs = "PKGS"; }
# => { lib = "LIB"; user = "USER"; }
```

Do not reverse the arguments.

Wrong:

```nix
builtins.intersectAttrs args (builtins.functionArgs fn)
```

That keeps values from `functionArgs`, usually booleans, not the actual context values.

## Safe optional projection call

Use when a value may be `null`, an attrset, or a function.

```nix
callProjection = args: projection:
  if projection == null then {
    config = {};
    collect = {};
  }
  else if builtins.isFunction projection then
    projection (builtins.intersectAttrs (builtins.functionArgs projection) args)
  else
    projection;
```

This accepts:

```nix
null
{}
{}: {}
{ lib }: {}
{ lib, ... }: {}
```

Caveat: `args: ...` receives `{}` because `functionArgs` cannot see positional argument names.

## `builtins.hasAttr`

Use for dynamic attrset membership.

```nix
builtins.hasAttr name attrs
```

Correct:

```nix
if builtins.hasAttr name modules then
  modules.${name}
else
  null
```

Do not confuse knownness with usability. `hasAttr` only says the key exists. It does not prove that the value is valid for the current module class or evaluation context.

For static keys, this is equivalent and clearer:

```nix
attrs ? key
```

For dynamic names, use `builtins.hasAttr`.

## `builtins.attrNames`

Use to turn an attrset into deterministic names.

```nix
builtins.attrNames { b = 1; a = 2; }
# => [ "a" "b" ]
```

Common pattern for enabled boolean flags:

```nix
enabledNames = attrs:
  builtins.attrNames (lib.filterAttrs (_: value: value == true) attrs);
```

Do not write:

```nix
lib.filterAttrs (_: value: value) attrs
```

unless every value is guaranteed to be a boolean. Nix conditionals do not have JavaScript-style truthiness.

## `lib.filterAttrs`

Use to filter an attrset by name and value.

```nix
lib.filterAttrs (name: value: value == true) attrs
```

Use it before `attrNames` when converting `{ name = bool; }` into `[ name ]`.

Bad pattern:

```nix
builtins.attrNames attrs
```

when disabled entries such as `{ foo = false; }` exist. That includes disabled names.

Good pattern:

```nix
builtins.attrNames (lib.filterAttrs (_: v: v == true) attrs)
```

## `lib.mapAttrs`

Use to transform attrset values while preserving keys.

```nix
lib.mapAttrs (name: value: value + 1) { a = 1; b = 2; }
# => { a = 2; b = 3; }
```

Do not use `mapAttrs` when you need a list. Use `lib.mapAttrsToList` or `lib.attrValues` after mapping.

```nix
lib.attrValues (lib.mapAttrs (_: value: value.module) attrs)
```

## `lib.attrValues`

Use to pass all attrset values into `imports`.

```nix
imports = lib.attrValues selectedModules;
```

This is correct when `selectedModules` is an attrset of module values.

Do not pass an attrset directly to `imports`.

Wrong:

```nix
imports = selectedModules;
```

Correct:

```nix
imports = lib.attrValues selectedModules;
```

## `builtins.foldl'`

Use strict folds for closure, accumulation, and graph-like traversal.

```nix
builtins.foldl' step initial list
```

Common closure pattern:

```nix
resolve = names:
  builtins.foldl'
    (acc: name:
      if builtins.elem name acc then acc
      else acc ++ [ name ])
    []
    names;
```

Be careful with accumulator type. If `acc` starts as a list, return a list. If it starts as an attrset, return an attrset.

Wrong:

```nix
builtins.foldl' (acc: x: acc // [ x ]) {} xs
```

`//` merges attrsets. It does not append lists.

## `builtins.elem`

Use for list membership.

```nix
builtins.elem name names
```

For attrset membership, use `builtins.hasAttr`.

Wrong:

```nix
builtins.elem name attrs
```

Correct:

```nix
builtins.hasAttr name attrs
```

## `builtins.seq`

Use to force validation before returning a lazy result.

Nix is lazy. A `let` binding does not force validation by itself.

Wrong:

```nix
let
  _ = assert condition;
in
result
```

Correct:

```nix
builtins.seq
  (assert condition; true)
  result
```

Use `seq` when a validation must happen before a module result is returned.

Caveat: `seq` only forces weak head normal form. It does not deeply evaluate every nested field.

## `//`

`//` is shallow attrset override.

```nix
{ a.b = 1; } // { a.c = 2; }
# => { a = { c = 2; }; }
```

It does not deep-merge nested attrsets. It does not perform NixOS module merging. It does not concatenate module option lists.

Do not use `//` to merge module configs.

Wrong:

```nix
config = fragmentA // fragmentB;
```

Correct:

```nix
imports = [
  { config = fragmentA; }
  { config = fragmentB; }
];
```

Let the module system merge options.

## `lib.mkMerge`

Use inside a module when multiple config fragments must be merged by the module system.

```nix
{ lib, ... }: {
  config = lib.mkMerge [
    { services.example.enable = true; }
    { environment.systemPackages = []; }
  ];
}
```

Do not use `mkMerge` as a replacement for normal attrset construction outside the module system.

Use it when option priorities, list merging, or submodule merging matter.

## `lib.unique`

Use only at the final boundary where deduplication is semantically correct.

```nix
lib.unique list
```

Do not dedupe too early if order or repeated definitions have meaning.

Good final-boundary pattern:

```nix
allowed = lib.unique config.local.packages.allowed;
```

## `lib.naturalSort`

Use for deterministic human-readable ordering of names.

```nix
lib.naturalSort names
```

Useful after computing a closure:

```nix
lib.naturalSort (lib.unique names)
```

Do not rely on incidental traversal order.

## Same attrpath assignment

Nix module assignments to the same option usually merge according to the option type.

Plain attrset assignment outside the module system does not.

Danger pattern:

```nix
flake.some.name.requires = [ "a" ];

flake.some.name = {
  value = true;
};
```

The second assignment may replace the earlier shape depending on the option type and evaluation context.

Prefer one complete attrset assignment:

```nix
flake.some.name = {
  requires = [ "a" ];
  value = true;
};
```

Or assign separate subfields without replacing the parent:

```nix
flake.some.name.requires = [ "a" ];
flake.some.name.value = true;
```

Do not assign the parent to a function after assigning its subfields.

Wrong:

```nix
flake.some.name.requires = [ "a" ];
flake.some.name = { lib, ... }: {};
```

## `builtins.getFlake` and local Git flakes

When evaluating a local Git flake, untracked files may not be present in the flake source copied to the Nix store.

Symptom:

```text
unknown attribute
unknown module
unknown feature
file exists on disk but evaluation cannot see it
```

Check Git visibility before changing Nix logic.

```bash
git status --short
git ls-files <path>
```

If a new file must be visible to flake evaluation:

```bash
git add <path>
```

Do not commit unless asked.

After staging, re-evaluate the attrset that should contain the new file:

```bash
nix eval .#modules.nixos --apply builtins.attrNames
```

Adapt the output path to the repository.

## `tryEval`

`builtins.tryEval` is shallow.

```nix
builtins.tryEval expr
```

It can report success while nested thunks still contain errors.

Do not treat `tryEval` success as proof that a whole module graph is valid.

Use targeted evaluation instead:

```bash
nix flake check
nix eval .#nixosConfigurations.<host>.config.system.build.toplevel.drvPath --raw
```

## Required verification

After changes involving attrsets, imports, flakes, or module functions, run:

```bash
git status --short
```

Then:

```bash
nix flake check
```

Then evaluate concrete outputs:

```bash
nix eval .#nixosConfigurations.<host>.config.system.build.toplevel.drvPath --raw
```

If a file was added or renamed, verify it is visible through the flake output, not merely present on disk.

## Final response format

Report facts only.

```md
## Result

- flake check: pass/fail
- concrete evals: pass/fail
- new files staged for flake visibility: yes/no

## Mistakes avoided

| Area | Check |
| --- | --- |
| functionArgs/intersectAttrs | argument filtering direction verified |
| module args | pkgs/modulesPath only used in inner module functions |
| attrset overwrite | no parent assignment after subfield assignment |
| local Git flake | new files are tracked or staged |
| module merge | no `//` used as module merge |
```
